package com.trios;

import javax.persistence.*;

import java.sql.SQLOutput;
import java.util.*;


public class App
{
    private static EntityManagerFactory emf=
            Persistence.createEntityManagerFactory("DBApp2");
    public static void main( String[] args )
    {
        Scanner scanner = new Scanner(System.in);


    }
    public static void createCustomer(String companyName,String contactName,String contactTitle,String address,String city,String region,String postalCode,String country,String phone,String fax){
        EntityManager em= emf.createEntityManager();
        EntityTransaction et = null;
        try{
            et=em.getTransaction();
            et.begin();
            Customer cust = new Customer();
            String firstThree;
            String lastTwo;
            if (companyName.length()>3){
                firstThree=companyName.substring(0,3);
            }else{
                firstThree=companyName;
            }
            if (phone.length()>2){
                lastTwo=phone.substring((phone.length())-2,phone.length());
            }else{
                lastTwo=phone;
            }
            cust.setCustomerID(firstThree+lastTwo);
            cust.setCompanyName(companyName);
            cust.setContactName(contactName);
            cust.setContactTitle(contactTitle);
            cust.setAddress(address);
            cust.setCity(city);
            cust.setRegion(region);
            cust.setPostalCode(postalCode);
            cust.setCountry(country);
            cust.setPhone(phone);
            cust.setFax(fax);
            em.persist(cust);
            et.commit();
        }catch(Exception ex){
            if(et!=null){
                et.rollback();
            }
        }finally {
            em.close();
        }
    }
    public static void updatingPhone(String custId,String phone){
        EntityManager em= emf.createEntityManager();
        String query_string;
        EntityTransaction et = null;
        try{

            TypedQuery<Customer> q =em.createQuery("select c from Customer where c.CustomerID=:id;",Customer.class);
            q.setParameter(custId,"id");
            et=em.getTransaction();
            et.begin();
            Customer C =q.getSingleResult();
            C.setPhone(phone);
            em.persist(C);
            et.commit();
        }catch(Exception ex){
            if(et!=null){
                et.rollback();
            }
        }finally {
            em.close();
        }
    }

    public static void deleteCustomer(String custId) {
        Scanner scanner = new Scanner(System.in);

        EntityManager em = emf.createEntityManager();
        try {
            System.out.println("DO YOU REALLY WANT TO DELETE CUSTOMER WITH CUSTOMER ID:");
            String text = scanner.nextLine();
            if(text=="yes"){
                TypedQuery<Customer> q =em.createQuery("delete c from Customer where c.CustomerID=:id;",Customer.class);
                q.setParameter(custId,"id");
                q.getSingleResult();

            }else{
                System.out.println("Deletion cancelled");
            }


        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            em.close();
        }


    }

    public static void getCustomer(int custId){
        EntityManager em= emf.createEntityManager();
        String query_string;
        try{
            TypedQuery<Customer> q =em.createQuery("select c from Customer where c.CustomerID=:id;",Customer.class);
            q.setParameter(custId,"id");
            Customer cust =q.getSingleResult();
            System.out.println(cust.getCompanyName()+cust.getContactName());


        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            em.close();
        }

    }
}
