package com.trios;
import javax.persistence.*;

@Entity
@Table ( name = "customers")
public class Customer {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name="CustomerID", unique = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name="CustomerID")
    private String CustomerID;

    @Column(name="CompanyName")
    private String CompanyName;

    @Column(name="ContactName")
    private String ContactName;

    @Column(name="ContactTitle")
    private String ContactTitle;

    @Column(name="Address")
    private String Address;

    @Column(name="City")
    private String City


    @Column(name="Region")
    private String Region;

    @Column(name="PostalCode")
    private String PostalCode;

    @Column(name="Country")
    private String Country;

    @Column(name="Phone")
    private String Phone;

    @Column(name="Fax")
    private String Fax;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public void setCompanyName(String CompanyName) {
        this.CompanyName = CompanyName;
    }

    public String getContactName() {
        return ContactName;
    }

    public void setContactName(String ContactName) {
        this.ContactName = ContactName;
    }

    public String getContactTitle() {
        return ContactTitle;
    }

    public void setContactTitle(String ContactTitle) {
        this.ContactTitle = ContactTitle;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getOfficeCode() {
        return officeCode;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String Region) {
        this.Region = Region;
    }

    public String getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(String PostalCode) {
        this.PostalCode = PostalCode;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public String getFax() {
        return Fax;
    }

    public void setFax(String Fax) {
        this.Fax = Fax;
    }

}
